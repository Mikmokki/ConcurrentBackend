package main

case class User(var friends: Array[String],var values:Map[String,String],var timestamp: Map[String,Long]){

}
